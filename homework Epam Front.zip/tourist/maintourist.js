const inputConvert = document.querySelector(".human__input");
const resultElement = document.querySelector(".result");

inputConvert.addEventListener("input", function() {
  let val = inputConvert.value;
  resultElement.innerText = val * 750 + " Доларів США";
});

const inputConvert1 = document.querySelector(".human__input1");
const resultElement1 = document.querySelector(".result1");

inputConvert1.addEventListener("input", function() {
  let val = inputConvert1.value;
  resultElement1.innerText = val * 400 + " Доларів США";
});

const inputConvert2 = document.querySelector(".human__input2");
const resultElement2 = document.querySelector(".result2");

inputConvert2.addEventListener("input", function() {
  let val = inputConvert2.value;
  resultElement2.innerText = val * 450 + " Доларів США";
});

const inputConvert3 = document.querySelector(".human__input3");
const resultElement3 = document.querySelector(".result3");

inputConvert3.addEventListener("input", function() {
  let val = inputConvert3.value;
  resultElement3.innerText = val * 350 + " Доларів США";
});

const inputConvert4 = document.querySelector(".human__input4");
const resultElement4 = document.querySelector(".result4");

inputConvert4.addEventListener("input", function() {
  let val = inputConvert4.value;
  resultElement4.innerText = val * 650 + " Доларів США";
});

const inputConvert5 = document.querySelector(".human__input5");
const resultElement5 = document.querySelector(".result5");

inputConvert5.addEventListener("input", function() {
  let val = inputConvert5.value;
  resultElement5.innerText = val * 550 + " Доларів США";
});

const inputConvert6 = document.querySelector(".human__input6");
const resultElement6 = document.querySelector(".result6");

inputConvert6.addEventListener("input", function() {
  let val = inputConvert6.value;
  resultElement6.innerText = val * 450 + " Доларів США";
});

const inputConvert7 = document.querySelector(".human__input7");
const resultElement7 = document.querySelector(".result7");

inputConvert7.addEventListener("input", function() {
  let val = inputConvert7.value;
  resultElement7.innerText = val * 450 + " Доларів США";
});

const inputConvert8 = document.querySelector(".human__input8");
const resultElement8 = document.querySelector(".result8");

inputConvert8.addEventListener("input", function() {
  let val = inputConvert8.value;
  resultElement8.innerText = val * 750 + " Доларів США";
});

function sortH2() {
  let select = document.getElementById("currencySelect");
  let sortOrder = select.options[select.selectedIndex].value;
  let h2Container = document.getElementById("h2Container");
  let h2Elements = h2Container.querySelectorAll(".plan");

  let sortedH2 = Array.from(h2Elements).sort(function(a, b) {
    let priceA = parseInt(a.getAttribute("data-price"));
    let priceB = parseInt(b.getAttribute("data-price"));

    if (sortOrder === "0") {
      return priceB - priceA;
    } else {
      return priceA - priceB;
    }
  });

  h2Container.innerHTML = '';

  sortedH2.forEach(function(element) {
    h2Container.appendChild(element);
  });
}

function sortByH2() {
  let select = document.getElementById("currencySelect1");
  let selectedRange = parseInt(select.options[select.selectedIndex].text.split(' ')[1]);
  let h2Container = document.getElementById("h2Container");
  let h2Elements = h2Container.querySelectorAll(".plan");

  h2Elements.forEach(function(element) {
    let price = parseInt(element.getAttribute("data-price"));
    if (selectedRange >= price) {
      element.style.display = "inline-block";
    } else {
      element.style.display = "none";
    }
  });
}



  




// function filterByPrice() {
//   let select1 = document.getElementById("currencySelect");
//   let selectedRange1 = parseInt(select1.options[select1.selectedIndex].text.split(' ')[1]);
//   let h2Container1 = document.getElementById("h2Container");
//   let h2Elements1 = h2Container1.querySelectorAll(".plan");

//   h2Elements1.forEach(function(element) {
//     let price = parseInt(element.getAttribute("data-price"));
//     if (selectedRange1 >= price) {
//       element.style.display = "inline-block";
//     } else {
//       element.style.display = "none";
//     }
//   });
// }